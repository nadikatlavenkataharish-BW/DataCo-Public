/*!
 * Gantt Chart — SAC custom widget (main)
 * Copyright (c) 2026 The Data Co (Pty) Ltd. All rights reserved.
 * PROPRIETARY AND CONFIDENTIAL. Licensed for use only under a written agreement with The Data Co (Pty) Ltd.
 * Unauthorised copying, modification or distribution is prohibited. See LICENSE.
 */
/* Gantt Chart — SAC custom widget (main component). Self-contained; no external libraries. */

/* =============================================================================
 * Gantt Chart — canonical renderer (v0.1)
 * -----------------------------------------------------------------------------
 * Pure function. No DOM dependency, no external libraries. Shared verbatim by
 * the SAC widget (inlined at build time) and preview.html (inlined too).
 *
 * records : [{ label, start: Date, end: Date, group?: string, color?: string, value?: number }]
 * opts    : see ganttDefaults().
 *
 * Layout: time on the x-axis, one row per record, optional group swimlanes,
 * a day/week/month axis, an optional "today" rule, categorical bar colour, and
 * the measure rendered as a value label on each bar. Sized to natural pixels so
 * the host container can scroll (Gantts are wide) rather than shrink to fit.
 * ========================================================================== */

function ganttDefaults() {
  return {
    title: "Project Timeline",
    subtitle: "Tasks by date",
    view: "week",                 // "day" | "week" | "month"
    weekStart: "monday",          // week tick alignment
    showToday: true,
    todayColor: "#E24C7B",
    barColor: "#4C78C8",          // used when no colour dimension is bound
    palette: ["#4C78C8","#F58518","#54A24B","#E45756","#72B7B2","#EECA3B","#B279A2","#FF9DA6","#9D755D","#BAB0AC"],
    showValueLabels: true,
    barHeight: 16,
    rowGap: 10,
    showLegend: true,
    sortBy: "start",              // "start" | "label"
    decimalSeparator: ",",
    labelWidth: 172,
    inkColor:  "#33414A",
    mutedColor:"#8794A0",
    gridLine:  "#E3E8ED",
    monthLine: "#C4CDD5",
    fontStack: "'72','72full',-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif"
  };
}

var G_MONTHS=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
var G_DAY=86400000;

function gEsc(s){ return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];}); }
function gTrunc(s, max){ s=String(s); return s.length>max ? s.slice(0,max-1)+"…" : s; }
function gCompact(v, sep){
  if(v==null||!isFinite(v)) return "";
  var n=Math.abs(v), s=v<0?"-":"";
  function t1(x){ return (Math.round(x*10)/10).toFixed(1).replace(/\.0$/,""); }
  if(n>=1e9) return s+t1(n/1e9)+"B";
  if(n>=1e6) return s+t1(n/1e6)+"M";
  if(n>=1e3) return s+t1(n/1e3)+"K";
  var r=(Math.round(n*100)/100).toString();
  return (s+r).replace(".", sep||".");
}
function gLum(hex){ hex=hex.replace("#",""); if(hex.length===3)hex=hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
  var r=parseInt(hex.slice(0,2),16),g=parseInt(hex.slice(2,4),16),b=parseInt(hex.slice(4,6),16);
  return (0.299*r+0.587*g+0.114*b)/255; }

function gDayStart(t){ var d=new Date(t); return Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate()); }
function gMonthStart(t){ var d=new Date(t); return Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),1); }
function gAddMonths(t,n){ var d=new Date(t); return Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+n,1); }
function gWeekStart(t,ws){ var d0=gDayStart(t); var wd=(new Date(d0).getUTCDay()-ws+7)%7; return d0-wd*G_DAY; }

function buildGanttSVG(records, opts){
  var o=ganttDefaults();
  opts=opts||{};
  for(var k in opts) if(opts[k]!==undefined && opts[k]!==null && opts[k]!=="") o[k]=opts[k];
  o.barHeight=+o.barHeight||16;

  var recs=(records||[]).filter(function(r){ return r && r.start && r.end && !isNaN(r.start) && !isNaN(r.end); })
    .map(function(r){
      var s=gDayStart(r.start.getTime()), e=gDayStart(r.end.getTime());
      if(e<s){ var t=s; s=e; e=t; }
      return { label:r.label!=null?String(r.label):"", start:s, end:e,
               group:(r.group!=null&&r.group!=="")?String(r.group):null,
               color:(r.color!=null&&r.color!=="")?String(r.color):null,
               value:(r.value!=null&&isFinite(r.value))?Number(r.value):null };
    });

  if(!recs.length){
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 520 120" font-family="'+o.fontStack+'">'+
      '<text x="260" y="60" text-anchor="middle" font-size="14" fill="'+o.mutedColor+'">Bind a label, a start date and an end date to begin.</text></svg>';
  }

  // ---- sort + group ------------------------------------------------------
  recs.sort(function(a,b){
    if(o.sortBy==="label"){ return a.label<b.label?-1:a.label>b.label?1:a.start-b.start; }
    return a.start-b.start || (a.label<b.label?-1:1);
  });
  var hasGroups=recs.some(function(r){ return r.group!=null; });
  var groups=[], gmap={};
  recs.forEach(function(r){ var g=hasGroups?(r.group||"(ungrouped)"):"__flat__";
    if(!(g in gmap)){ gmap[g]=[]; groups.push(g); } gmap[g].push(r); });

  // ---- colour categories -------------------------------------------------
  var hasColor=recs.some(function(r){ return r.color!=null; });
  var catColor={}, cats=[];
  if(hasColor){ recs.forEach(function(r){ if(r.color!=null && !(r.color in catColor)){ catColor[r.color]=o.palette[cats.length%o.palette.length]; cats.push(r.color); } }); }
  function barFill(r){ return (hasColor && r.color!=null) ? catColor[r.color] : o.barColor; }

  // ---- time domain (snap to whole months) --------------------------------
  var minS=Infinity, maxE=-Infinity;
  recs.forEach(function(r){ if(r.start<minS)minS=r.start; if(r.end>maxE)maxE=r.end; });
  var domainStart=gMonthStart(minS), domainEnd=gAddMonths(gMonthStart(maxE),1);
  var totalDays=Math.max(1,(domainEnd-domainStart)/G_DAY);
  var pxPerDay = o.view==="day"?22 : o.view==="month"?3.4 : 9.5;
  var plotW=totalDays*pxPerDay;
  var wsNum=o.weekStart==="sunday"?0:1;

  var padL=18, padR=24, padB=18;
  var gutter=Math.max(60, +o.labelWidth||172), plotLeft=padL+gutter;
  var labelMax=Math.max(6, Math.floor((gutter-padL-12)/6.3));   // fit chars to the gutter width
  function X(t){ return plotLeft+((t-domainStart)/G_DAY)*pxPerDay; }

  var headerTop=72, coarseH=18, fineH=16, gridTop=headerTop+coarseH+fineH;
  var rowH=o.barHeight+o.rowGap, groupH=hasGroups?24:0;

  // ---- row layout --------------------------------------------------------
  var rows=[], y=gridTop+6;
  groups.forEach(function(g){
    if(hasGroups){ rows.push({type:"group", label:g, y:y}); y+=groupH; }
    gmap[g].forEach(function(r){ rows.push({type:"item", rec:r, y:y}); y+=rowH; });
  });
  var gridBottom=y+2;
  var W=plotLeft+plotW+padR, H=gridBottom+padB;

  var grid=[], barsG=[], labelsG=[], axisG=[];

  // ---- axis: month band (coarse) + fine ticks + gridlines ----------------
  for(var mt=domainStart; mt<domainEnd; mt=gAddMonths(mt,1)){
    var mx=X(mt);
    grid.push('<line x1="'+mx+'" y1="'+(gridTop)+'" x2="'+mx+'" y2="'+gridBottom+'" stroke="'+o.monthLine+'" stroke-width="1"/>');
    var md=new Date(mt), lbl=G_MONTHS[md.getUTCMonth()]+(md.getUTCMonth()===0?" "+md.getUTCFullYear():"");
    axisG.push('<text x="'+(mx+4)+'" y="'+(headerTop+13)+'" font-size="11" font-weight="600" fill="'+o.inkColor+'">'+lbl+'</text>');
  }
  // fine ticks depend on the view
  var fineY=headerTop+coarseH+12;
  if(o.view==="day"){
    for(var dt=domainStart; dt<domainEnd; dt+=G_DAY){
      var dx=X(dt), dow=new Date(dt).getUTCDay(), we=(dow===0||dow===6);
      grid.push('<line x1="'+dx+'" y1="'+gridTop+'" x2="'+dx+'" y2="'+gridBottom+'" stroke="'+o.gridLine+'" stroke-width="'+(we?1:0.5)+'"'+(we?' opacity="0.9"':' opacity="0.6"')+'/>');
      axisG.push('<text x="'+(dx+pxPerDay/2)+'" y="'+fineY+'" text-anchor="middle" font-size="9" fill="'+o.mutedColor+'">'+new Date(dt).getUTCDate()+'</text>');
    }
  } else if(o.view==="week"){
    var w0=gWeekStart(domainStart,wsNum);
    for(var wt=w0; wt<domainEnd; wt+=7*G_DAY){
      if(wt<domainStart) continue;
      var wx=X(wt);
      grid.push('<line x1="'+wx+'" y1="'+gridTop+'" x2="'+wx+'" y2="'+gridBottom+'" stroke="'+o.gridLine+'" stroke-width="0.75"/>');
      var wd=new Date(wt);
      axisG.push('<text x="'+(wx+3)+'" y="'+fineY+'" font-size="9" fill="'+o.mutedColor+'">'+wd.getUTCDate()+"/"+(wd.getUTCMonth()+1)+'</text>');
    }
  } else { // month view: coarse band shows months; fine row shows the year (once per year)
    for(var mt2=domainStart; mt2<domainEnd; mt2=gAddMonths(mt2,1)){
      var md2=new Date(mt2);
      if(md2.getUTCMonth()===0 || mt2===domainStart)
        axisG.push('<text x="'+(X(mt2)+4)+'" y="'+fineY+'" font-size="9" font-weight="600" fill="'+o.mutedColor+'">'+md2.getUTCFullYear()+'</text>');
    }
  }

  // ---- rows: group headers, task labels, bars ----------------------------
  rows.forEach(function(row){
    if(row.type==="group"){
      labelsG.push('<rect x="'+padL+'" y="'+row.y+'" width="'+(W-padL-padR)+'" height="'+groupH+'" fill="#F2F5F8"/>');
      labelsG.push('<text x="'+padL+'" y="'+(row.y+16)+'" font-size="12" font-weight="700" fill="'+o.inkColor+'">'+gEsc(gTrunc(row.label,Math.max(labelMax,40)))+'</text>');
      return;
    }
    var r=row.rec, by=row.y, bh=o.barHeight;
    // task label in the gutter
    labelsG.push('<text x="'+padL+'" y="'+(by+bh*0.78)+'" font-size="11.5" fill="'+o.inkColor+'">'+gEsc(gTrunc(r.label,labelMax))+'</text>');
    // bar
    var x0=X(r.start), x1=X(r.end+G_DAY); // end-inclusive
    var bw=Math.max(3, x1-x0), fill=barFill(r);
    barsG.push('<rect x="'+x0+'" y="'+by+'" width="'+bw+'" height="'+bh+'" rx="3" fill="'+fill+'"/>');
    // value label
    if(o.showValueLabels && r.value!=null){
      var txt=gCompact(r.value, o.decimalSeparator);
      var tw=txt.length*6.4+8;
      if(tw<=bw){ // inside
        var tc=gLum(fill)<0.6?"#FFFFFF":o.inkColor;
        barsG.push('<text x="'+(x0+bw/2)+'" y="'+(by+bh*0.72)+'" text-anchor="middle" font-size="10.5" font-weight="600" fill="'+tc+'">'+gEsc(txt)+'</text>');
      } else { // to the right
        barsG.push('<text x="'+(x1+4)+'" y="'+(by+bh*0.72)+'" font-size="10.5" font-weight="600" fill="'+o.mutedColor+'">'+gEsc(txt)+'</text>');
      }
    }
  });

  // ---- today rule --------------------------------------------------------
  var overlay=[];
  if(o.showToday){
    var today=gDayStart(Date.now());
    if(today>=domainStart && today<domainEnd){
      var tx=X(today);
      overlay.push('<line x1="'+tx+'" y1="'+(gridTop-2)+'" x2="'+tx+'" y2="'+gridBottom+'" stroke="'+o.todayColor+'" stroke-width="1.5" stroke-dasharray="4 3"/>');
      overlay.push('<text x="'+tx+'" y="'+(gridTop-4)+'" text-anchor="middle" font-size="9.5" font-weight="700" fill="'+o.todayColor+'">Today</text>');
    }
  }

  // ---- header + legend ---------------------------------------------------
  var head=[];
  head.push('<text x="'+padL+'" y="34" font-size="22" font-weight="700" fill="'+o.inkColor+'">'+gEsc(o.title)+'</text>');
  if(o.subtitle) head.push('<text x="'+padL+'" y="54" font-size="13" fill="'+o.mutedColor+'">'+gEsc(o.subtitle)+'</text>');
  if(o.showLegend && hasColor){
    var lx=plotLeft, ly=48, cur=lx;
    for(var i=0;i<cats.length;i++){
      var w=16+String(cats[i]).length*6.2+16;
      if(cur+w>W-padR){ break; }
      head.push('<rect x="'+cur+'" y="'+(ly-9)+'" width="11" height="11" rx="2" fill="'+catColor[cats[i]]+'"/>');
      head.push('<text x="'+(cur+16)+'" y="'+ly+'" font-size="11" fill="'+o.mutedColor+'">'+gEsc(gTrunc(cats[i],18))+'</text>');
      cur+=w;
    }
  }

  // axis baseline under the fine row
  grid.push('<line x1="'+plotLeft+'" y1="'+gridTop+'" x2="'+(W-padR)+'" y2="'+gridTop+'" stroke="'+o.monthLine+'" stroke-width="1"/>');

  return '<svg xmlns="http://www.w3.org/2000/svg" width="'+W+'" height="'+H+'" viewBox="0 0 '+W+' '+H+
    '" font-family="'+o.fontStack+'"><rect x="0" y="0" width="'+W+'" height="'+H+'" fill="#FFFFFF"/>'+
    grid.join("")+axisG.join("")+labelsG.join("")+barsG.join("")+overlay.join("")+head.join("")+'</svg>';
}

if(typeof module!=="undefined" && module.exports){ module.exports={ buildGanttSVG:buildGanttSVG }; }

/* =============================================================================
 * Gantt Chart — SAC main web component (v0.1)
 * -----------------------------------------------------------------------------
 * Data model — one row per item, via named feeds:
 *   label     (dimension)          - the task name (row)
 *   startDate (dimension)          - start date (day granularity)
 *   endDate   (dimension)          - end date
 *   groupDim  (dimension, optional)- swimlane grouping
 *   colorDim  (dimension, optional)- categorical bar colour
 *   measures  (measure,   optional)- value shown as a label on the bar
 *
 * Each feed's assigned field is read via metadata.feeds.<feedId>.values[0].
 * The root scrolls (Gantts are wide) rather than shrinking to fit the tile.
 * ========================================================================== */

(function () {
  "use strict";

  var template = document.createElement("template");
  template.innerHTML =
    '<style>' +
    '  :host { display:block; width:100%; height:100%; }' +
    '  #root { width:100%; height:100%; overflow:auto; }' +
    '  #root svg { display:block; }' +
    '  .g-msg { width:100%; height:100%; display:flex; align-items:center; justify-content:center;' +
    '           font-family:\'72\',-apple-system,\'Segoe UI\',Roboto,sans-serif; color:#8794A0; font-size:13px; text-align:center; padding:0 16px; }' +
    '</style>' +
    '<div id="root"></div>';

  function feedKey(metadata, id) {
    var f = metadata && metadata.feeds && metadata.feeds[id];
    return (f && f.values && f.values.length) ? f.values[0] : null;
  }

  function parseSacDate(cell) {
    if (!cell) return null;
    var cands = [cell.id, cell.label, cell.description];
    for (var i = 0; i < cands.length; i++) {
      var raw = cands[i]; if (raw == null) continue;
      var s = String(raw).trim();
      var digits = s.replace(/[^0-9]/g, "");
      if (digits.length >= 8) {
        var y = +digits.slice(0, 4), m = +digits.slice(4, 6), d = +digits.slice(6, 8);
        if (y > 1900 && m >= 1 && m <= 12 && d >= 1 && d <= 31) return new Date(Date.UTC(y, m - 1, d));
      }
      var iso = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
      if (iso) return new Date(Date.UTC(+iso[1], +iso[2] - 1, +iso[3]));
      var t = Date.parse(s);
      if (!isNaN(t)) { var dt = new Date(t); return new Date(Date.UTC(dt.getFullYear(), dt.getMonth(), dt.getDate())); }
    }
    return null;
  }

  function label(cell) { return cell ? (cell.label != null ? cell.label : cell.id) : null; }

  function buildRecords(dataBinding) {
    var data = dataBinding.data || [], md = dataBinding.metadata || {};
    var kLabel = feedKey(md, "label"), kStart = feedKey(md, "startDate"), kEnd = feedKey(md, "endDate");
    var kGroup = feedKey(md, "groupDim"), kColor = feedKey(md, "colorDim"), kMeas = feedKey(md, "measures");
    if (!kLabel || !kStart || !kEnd) return { recs: [], missing: true };
    var recs = [];
    data.forEach(function (row) {
      var start = parseSacDate(row[kStart]), end = parseSacDate(row[kEnd]);
      if (!start || !end) return;
      recs.push({
        label: label(row[kLabel]) || "",
        start: start, end: end,
        group: kGroup ? label(row[kGroup]) : null,
        color: kColor ? label(row[kColor]) : null,
        value: kMeas && row[kMeas] ? Number(row[kMeas].raw) : null
      });
    });
    return { recs: recs, missing: false };
  }

  class GanttChart extends HTMLElement {
    constructor() {
      super();
      this._shadowRoot = this.attachShadow({ mode: "open" });
      this._shadowRoot.appendChild(template.content.cloneNode(true));
      this._root = this._shadowRoot.getElementById("root");
      this._props = {};
    }
    onCustomWidgetBeforeUpdate(changedProps) { this._props = Object.assign({}, this._props, changedProps); }
    onCustomWidgetAfterUpdate() { this.render(); }
    onCustomWidgetResize() { this.render(); }
    onCustomWidgetDestroy() { this._root.innerHTML = ""; }

    render() {
      if (!document.contains(this)) { setTimeout(this.render.bind(this), 0); return; }
      var binding = this.dataBinding;
      if (!binding || binding.state !== "success") {
        this._root.innerHTML = '<div class="g-msg">Bind a label, a start date and an end date to see the timeline.</div>';
        return;
      }
      var out = buildRecords(binding);
      if (out.missing) { this._root.innerHTML = '<div class="g-msg">Assign the Label, Start date and End date feeds.</div>'; return; }
      if (!out.recs.length) { this._root.innerHTML = '<div class="g-msg">No rows with a valid start and end date.</div>'; return; }
      this._root.innerHTML = buildGanttSVG(out.recs, this._props);
    }
  }

  customElements.define("com-dvc-sac-ganttchart", GanttChart);
})();
